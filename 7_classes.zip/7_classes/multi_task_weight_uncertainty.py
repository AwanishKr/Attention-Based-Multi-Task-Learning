
from __future__ import print_function, division
import torch
from torch import nn
import torch.nn.functional as F
import torch.optim as optim
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import numpy as np
import torchvision
from torchvision import datasets, models, transforms
import matplotlib.pyplot as plt
import time
import os
import copy
import math
from create_dataset_weight_uncertainty import *
from torch.autograd import Variable


def att_layer(in_dim1, in_dim2, out_dim):
	a1 = nn.Conv2d(in_dim1, in_dim2, kernel_size=1, padding=0)
	a1 = nn.BatchNorm2d(in_dim1)
	a1 = nn.ReLU(inplace= True)
	a1 = nn.Conv2d(in_dim2, out_dim ,kernel_size=1, padding=0)
	a1 = nn.BatchNorm2d(out_dim)
	a1 = nn.ReLU(inplace=True)
	a1 = nn.Sigmoid()
	return a1

class UNet(nn.Module):
	def __init__(self, in_dim, out_dim1, out_dim2):
		super(UNet, self).__init__()
		self.in_dim = in_dim
		self.out_dim1 = out_dim1
		self.out_dim2 = out_dim2
		
		filters = [64, 128, 256, 512, 1024]
		value = 0.2
		# down_pool = nn.MaxPool2d(kernel_size=2, stride=2)
		self.general_maxpool = nn.MaxPool2d(kernel_size=2, stride=2)
		
#---------------------------------------------------------Encoder Block 1 --------------------------------------------------------------
		self.dn1 = nn.Conv2d(self.in_dim, filters[0], kernel_size= 3, stride=1, padding=1)
		self.bn1 = nn.BatchNorm2d(filters[0])
		self.ac1 = nn.LeakyReLU(value, inplace=True)
		self.dn2 = nn.Conv2d(filters[0], filters[0], kernel_size=3, stride=1, padding=1)
		self.bn2 = nn.BatchNorm2d(filters[0])
		self.ac2 = nn.LeakyReLU(value, inplace=True)
		self.drop2 = nn.Dropout2d(p=0.5, inplace=False)
		self.mp1 = nn.MaxPool2d(kernel_size=2, stride=2)

#---------------------------------------------------------Encoder Block 2 --------------------------------------------------------------
		self.dn3 = nn.Conv2d((filters[0]+filters[0]), filters[1], kernel_size=3, stride=1, padding=1)
		self.bn3 = nn.BatchNorm2d(filters[1])
		self.ac3 = nn.LeakyReLU(value, inplace=True)
		self.dn4 = nn.Conv2d((filters[1]+filters[0]+filters[0]), filters[1], kernel_size=3, stride=1, padding=1)
		self.bn4 = nn.BatchNorm2d(filters[1])
		self.ac4 = nn.LeakyReLU(value, inplace=True)
		self.drop4 = nn.Dropout2d(p=0.5, inplace=False)
		self.mp2 = nn.MaxPool2d(kernel_size=2, stride=2)
		
#---------------------------------------------------------Encoder Block 3 --------------------------------------------------------------		
		self.dn5 = nn.Conv2d((filters[1]+filters[1]+filters[0]+filters[0]), filters[2], kernel_size=3, stride=1, padding=1)
		self.bn5 = nn.BatchNorm2d(filters[2])
		self.ac5 = nn.LeakyReLU(value, inplace=True)
		self.dn6 = nn.Conv2d((filters[2]+filters[1]+filters[1]+filters[0]+filters[0]), filters[2], kernel_size=3, stride=1, padding=1)
		self.bn6 = nn.BatchNorm2d(filters[2])
		self.ac6 = nn.LeakyReLU(value, inplace=True)
		self.drop6 = nn.Dropout2d(p=0.5, inplace=False)
		self.mp3 = nn.MaxPool2d(kernel_size=2, stride=2)
		
#---------------------------------------------------------Encoder Block 4 --------------------------------------------------------------		
		self.dn7 = nn.Conv2d((filters[2]+filters[2]+filters[1]+filters[1]+filters[0]+filters[0]), filters[3], kernel_size=3, stride=1, padding=1)
		self.bn7 = nn.BatchNorm2d(filters[3])
		self.ac7 = nn.LeakyReLU(value, inplace=True)
		self.dn8 = nn.Conv2d((filters[3]+filters[2]+filters[2]+filters[1]+filters[1]+filters[0]+filters[0]), filters[3], kernel_size=3, stride=1, padding=1)
		self.bn8 = nn.BatchNorm2d(filters[3])
		self.ac8 = nn.LeakyReLU(value, inplace=True)
		self.drop8 = nn.Dropout2d(p=0.5, inplace=False)
		self.mp4 = nn.MaxPool2d(kernel_size=2, stride=2)


#---------------------------------------------------------bottleneck --------------------------------------------------------------		
		self.dn9 = nn.Conv2d(filters[3], filters[4], kernel_size=3, stride=1, padding=1)
		self.bn9 = nn.BatchNorm2d(filters[4])
		self.ac9 = nn.LeakyReLU(value, inplace=True)
		self.dn10 = nn.Conv2d(filters[4], filters[4], kernel_size=3, stride=1, padding=1)
		self.bn10 = nn.BatchNorm2d(filters[4])
		self.ac10 = nn.LeakyReLU(value, inplace=True)
		self.tr1 = nn.ConvTranspose2d(filters[4], filters[3], kernel_size=3, stride=2, padding=1, output_padding=1)
										


#---------------------------------------------------------Decoder Block semantic 4 --------------------------------------------------------------
		self.up1 = nn.Conv2d(filters[4], filters[3], kernel_size=3, stride=1, padding=1)
		self.bn11 = nn.BatchNorm2d(filters[3])
		self.ac11 = nn.LeakyReLU(value, inplace=True)
		self.up2 = nn.Conv2d(filters[3], filters[3], kernel_size=3, stride=1, padding=1)
		self.bn12 = nn.BatchNorm2d(filters[3])
		self.ac12 = nn.LeakyReLU(value, inplace=True)		
		self.tr2 = nn.ConvTranspose2d(filters[3], filters[2], kernel_size=3, stride=2, padding=1, output_padding=1)
									
		#########Attenstion Mask 1 ##########
		self.att_mask1 = att_layer(filters[3], filters[3], filters[3])

#---------------------------------------------------------Decoder Block semantic 3 --------------------------------------------------------------		
		self.up3 = nn.Conv2d(filters[3], filters[2], kernel_size=3, stride=1, padding=1)
		self.bn13 = nn.BatchNorm2d(filters[2])
		self.ac13 = nn.LeakyReLU(value, inplace=True)
		self.up4 = nn.Conv2d(filters[2], filters[2], kernel_size=3, stride=1, padding=1)
		self.bn14 = nn.BatchNorm2d(filters[2])
		self.ac14 = nn.LeakyReLU(value, inplace=True)
		self.tr3 = nn.ConvTranspose2d(filters[2], filters[1], kernel_size=3, stride=2, padding=1, output_padding=1)
		
		#########Attenstion Mask 2 ##########
		self.att_mask2 = att_layer(filters[2], filters[2], filters[2])

#---------------------------------------------------------Decoder Block semantic 2 --------------------------------------------------------------		
		self.up5 = nn.Conv2d((filters[1]+filters[1]+filters[1]) , filters[1], kernel_size=3, stride=1, padding=1)
		self.bn15 = nn.BatchNorm2d(filters[1])
		self.ac15 = nn.LeakyReLU(value, inplace=True)
		self.up6 = nn.Conv2d(filters[1], filters[1], kernel_size=3, stride=1, padding=1)
		self.bn16 = nn.BatchNorm2d(filters[1])
		self.ac16 = nn.LeakyReLU(value, inplace=True)
		self.tr4 = nn.ConvTranspose2d(filters[1], filters[0], kernel_size=3, stride=2, padding=1, output_padding=1)
									
		#########Attenstion Mask 3 ##########
		self.att_mask3 = att_layer(filters[1], filters[1], filters[1])

#---------------------------------------------------------Decoder Block semantic 1 --------------------------------------------------------------		
		self.up7 = nn.Conv2d(filters[1], filters[0], kernel_size=3, stride=1, padding=1)
		self.bn17 = nn.BatchNorm2d(filters[0])
		self.ac17 = nn.LeakyReLU(value, inplace=True)
		self.up8 = nn.Conv2d(filters[0], filters[0], kernel_size=3, stride=1, padding=1)
		self.bn18 = nn.BatchNorm2d(filters[0])
		self.ac18 = nn.LeakyReLU(value, inplace=True)
	
		#########Attenstion Mask 4 ##########
		self.att_mask4 = att_layer(filters[0], filters[0], filters[0])
		self.ac_out1 = nn.Conv2d(filters[0], out_dim1, kernel_size=3, stride=1, padding=1)



#---------------------------------------------------------Decoder Block depth 4 --------------------------------------------------------------		
		self.up9 = nn.Conv2d(filters[4], filters[3], kernel_size=3, stride=1, padding=1)
		self.bn19 = nn.BatchNorm2d(filters[3])
		self.ac19 = nn.LeakyReLU(value, inplace=True)
		self.up10 = nn.Conv2d(filters[3], filters[3], kernel_size=3, stride=1, padding=1)
		self.bn20 = nn.BatchNorm2d(filters[3])
		self.ac20 = nn.LeakyReLU(value, inplace=True)
		self.tr5 = nn.ConvTranspose2d(filters[3], filters[2], kernel_size=3, stride=2, padding=1, output_padding=1)
		
		#########Attenstion Mask 1 ##########
		self.att_mask5 = att_layer(filters[3], filters[3], filters[3])

#---------------------------------------------------------Decoder Block depth 3 --------------------------------------------------------------		
		self.up11 = nn.Conv2d(filters[3], filters[2], kernel_size=3, stride=1, padding=1)
		self.bn21 = nn.BatchNorm2d(filters[2])
		self.ac21 = nn.LeakyReLU(value, inplace=True)
		self.up12 = nn.Conv2d(filters[2], filters[2], kernel_size=3, stride=1, padding=1)
		self.bn22 = nn.BatchNorm2d(filters[2])
		self.ac22 = nn.LeakyReLU(value, inplace=True)		
		self.tr6 = nn.ConvTranspose2d(filters[2], filters[1], kernel_size=3, stride=2, padding=1, output_padding=1)
												
		#########Attenstion Mask 2 ##########								
		self.att_mask6 = att_layer(filters[2], filters[2], filters[2])

#---------------------------------------------------------Decoder Block depth 2 --------------------------------------------------------------
		self.up13 = nn.Conv2d(filters[1]+filters[1]+filters[1] , filters[1], kernel_size=3, stride=1, padding=1)
		self.bn23 = nn.BatchNorm2d(filters[1])
		self.ac23 = nn.LeakyReLU(value, inplace=True)
		self.up14 = nn.Conv2d(filters[1], filters[1], kernel_size=3, stride=1, padding=1)
		self.bn24 = nn.BatchNorm2d(filters[1])
		self.ac24 = nn.LeakyReLU(value, inplace=True)
		self.tr7 = nn.ConvTranspose2d(filters[1], filters[0], kernel_size=3, stride=2, padding=1, output_padding=1)
									
		#########Attenstion Mask 3 ##########
		self.att_mask7 = att_layer(filters[1], filters[1], filters[1])

#---------------------------------------------------------Decoder Block depth 1 --------------------------------------------------------------		
		self.up15 = nn.Conv2d(filters[1], filters[0], kernel_size=3, stride=1, padding=1)
		self.bn25 = nn.BatchNorm2d(filters[0])
		self.ac25 = nn.LeakyReLU(value, inplace=True)
		self.up16 = nn.Conv2d(filters[0], filters[0], kernel_size=3, stride=1, padding=1)
		self.bn26 = nn.BatchNorm2d(filters[0])
		self.ac26 = nn.LeakyReLU(value, inplace=True)

		#########Attenstion Mask 4 ##########
		self.att_mask8 = att_layer(filters[0], filters[0], filters[0])
		self.ac_out2 = nn.Conv2d(filters[0], out_dim2, kernel_size=3, stride=1, padding=1)


	def forward(self, x):
		#ENC Block1
		dn1 = self.dn1(x)
		bn1 = self.bn1(dn1)
		ac1 = self.ac1(bn1)

		dn2 = self.dn2(ac1)
		bn2 = self.bn2(dn2)
		ac2 = self.ac2(bn2)
		drop2 = self.drop2(ac2)
		
		mp1 = self.mp1(drop2)
		
		temp_1 = self.general_maxpool(ac1)
		cat_1 = torch.cat([mp1, temp_1], dim =1)

		#ENC Block2
		dn3 = self.dn3(cat_1)
		bn3 = self.bn3(dn3)
		ac3 = self.ac3(bn3)

		cat_2 = torch.cat([ac3, mp1, temp_1], dim =1)

		dn4 = self.dn4(cat_2)
		bn4 = self.bn4(dn4)
		ac4 = self.ac4(bn4)
		drop4 = self.drop4(ac4)
		mp2 = self.mp2(drop4)
		
		temp_2 = self.general_maxpool(ac3)
		temp_3 = self.general_maxpool(temp_1)
		temp_4 = self.general_maxpool(mp1)
		
		cat_3 = torch.cat([mp2, temp_2, temp_4, temp_3], dim =1)	

		#ENC Block3
		dn5 = self.dn5(cat_3)
		bn5 = self.bn5(dn5)
		ac5 = self.ac5(bn5)

		cat_4 = torch.cat([ac5, mp2, temp_2, temp_4, temp_3], dim =1)

		dn6 = self.dn6(cat_4)
		bn6 = self.bn6(dn6)
		ac6 = self.ac6(bn6)
		drop6 = self.drop6(ac6)
		mp3 = self.mp3(drop6)

		temp_5 = self.general_maxpool(ac5)
		temp_6 = self.general_maxpool(mp2)
		temp_7 = self.general_maxpool(temp_2)
		temp_8 = self.general_maxpool(temp_4)
		temp_9 = self.general_maxpool(temp_3)

		cat_5 = torch.cat([mp3, temp_5, temp_6, temp_7, temp_8, temp_9], dim =1)
		
		#ENC Block4
		dn7 = self.dn7(cat_5)
		bn7 = self.bn7(dn7)
		ac7 = self.ac7(bn7)

		cat_6 = torch.cat([ac7, mp3, temp_5, temp_6, temp_7, temp_8, temp_9], dim =1)

		dn8 = self.dn8(cat_6)
		bn8 = self.bn8(dn8)
		ac8 = self.ac8(bn8)
		drop8 = self.drop8(ac8)
		mp4 = self.mp4(drop8)
#-------------------------------final output of encoder is mp4 which is 8x16 in dimension and has 512 channels exactly like before-----------------		

		#Block Bridge
		dn9 = self.dn9(mp4)
		bn9 = self.bn9(dn9)
		ac9 = self.ac9(bn9)
		dn10 = self.dn10(ac9)
		bn10 = self.bn10(dn10)
		ac10 = self.ac10(bn10)
		tr1 = self.tr1(ac10)

		#DEC Block4 semantic
		link1 = torch.cat([tr1, drop8], dim =1)
		up1 = self.up1(link1)
		bn11 = self.bn11(up1)
		ac11 = self.ac11(bn11)
		up2 = self.up2(ac11)
		bn12 = self.bn12(up2)
		ac12 = self.ac12(bn12)
		att_mask1 = self.att_mask1(ac11)
		a_hat1 = (att_mask1)* ac12
		tr2 = self.tr2(a_hat1)

		#DEC Block4 depth
		link1 = torch.cat([tr1, drop8], dim =1)
		up9 = self.up9(link1)
		bn19 = self.bn19(up9)
		ac19 = self.ac19(bn19)
		up10 = self.up10(ac19)
		bn20 = self.bn20(up10)
		ac20 = self.ac20(bn20)
		att_mask5 = self.att_mask5(ac19)
		a_hat5 = (att_mask5)* ac20
		tr5 = self.tr5(a_hat5)

		# #DEC Block3 semantic
		link2 = torch.cat([tr2, drop6], dim =1)
		up3 = self.up3(link2)
		bn13 = self.bn13(up3)
		ac13 = self.ac13(bn13)
		up4 = self.up4(ac13)
		bn14 = self.bn14(up4)
		ac14 = self.ac14(bn14)
		att_mask2 = self.att_mask2(ac13)
		a_hat2 = (att_mask2)* ac14
		tr3 = self.tr3(a_hat2)

		#DEC Block3 depth
		link5 = torch.cat([tr5, drop6], dim =1)
		up11 = self.up11(link5)
		bn21 = self.bn21(up11)
		ac21 = self.ac21(bn21)
		up12 = self.up12(ac21)
		bn22 = self.bn22(up12)
		ac22 = self.ac22(bn22)
		att_mask6 = self.att_mask6(ac21)
		a_hat6 = (att_mask6)* ac22
		tr6 = self.tr6(a_hat6)

		#DEC Block2 semantic
		link3 = torch.cat([tr3, drop4, tr6], dim =1)
		up5 = self.up5(link3)
		bn15 = self.bn15(up5)
		ac15 = self.ac15(bn15)
		up6 = self.up6(ac15)
		bn16 = self.bn16(up6)
		ac16 = self.ac16(bn16)
		att_mask3 = self.att_mask3(ac15)
		a_hat3 = (att_mask3)* ac16
		tr4 = self.tr4(a_hat3)

		#DEC Block2 depth
		link6 = torch.cat([tr6, drop4, tr3], dim =1)
		up13 = self.up13(link6)
		bn23 = self.bn23(up13)
		ac23 = self.ac23(bn23)
		up14 = self.up14(ac23)
		bn24 = self.bn24(up14)
		ac24 = self.ac24(bn24)
		att_mask7 = self.att_mask7(ac23)
		a_hat7 = (att_mask7)* ac24
		tr7 = self.tr7(a_hat7)

		# #DEC Block1 semantic
		link4 = torch.cat([tr4, drop2], dim =1)
		up7 = self.up7(link4)
		bn17 = self.bn17(up7)
		ac17 = self.ac17(bn17)
		up8 = self.up8(ac17)
		bn18 = self.bn18(up8)
		ac18 = self.ac18(bn18)
		att_mask4 = self.att_mask4(ac17)
		#torchvision.utils.save_image(att_mask4[0:2, 0:3], "attention_semantic.jpg")		
		a_hat4 = (att_mask4)* ac18
		ac_out1 = self.ac_out1(a_hat4)

		#DEC Block1 depth
		link7 = torch.cat([tr7, drop2], dim =1)
		up15 = self.up15(link7)
		bn25 = self.bn25(up15)
		ac25 = self.ac25(bn25)
		up16 = self.up16(ac25)
		bn26 = self.bn26(up16)
		ac26 = self.ac26(bn26)
		att_mask8 = self.att_mask8(ac25)
		#torchvision.utils.save_image(att_mask8[0:2, 0:3], "attention_depth.jpg")		
		a_hat8 = (att_mask8)* ac26
		ac_out2 = self.ac_out2(a_hat8)
		
		return ac_out1, ac_out2

def compute_miou(x_pred, x_output):
	_, x_pred_label = torch.max(x_pred, dim=1)
	x_output_label = x_output
	batch_size = x_pred.size(0)
	for i in range(batch_size):
		true_class = 0
		first_switch = True
		for j in range(7):
			# pred_mask = torch.eq(x_pred_label[i], Variable(j * torch.ones(x_pred_label[i].shape).type(torch.LongTensor)))
			# true_mask = torch.eq(x_output_label[i], Variable(j * torch.ones(x_output_label[i].shape).type(torch.LongTensor)))
			pred_mask = torch.eq(x_pred_label[i], Variable(j*torch.ones(x_pred_label[i].shape).type(torch.LongTensor).cuda(c)))
			true_mask = torch.eq(x_output_label[i], Variable(j * torch.ones(x_output_label[i].shape).type(torch.FloatTensor)))
			mask_comb = pred_mask + true_mask.cuda(c)
			union = torch.sum((mask_comb > 0).type(torch.FloatTensor))
			intsec = torch.sum((mask_comb > 1).type(torch.FloatTensor))
			
			if union == 0:
				continue
			if first_switch:
				class_prob = intsec/ union
				first_switch = False
			else:
				class_prob = intsec / union + class_prob
				true_class += 1
		
		if i == 0:
			batch_avg = (class_prob) / (true_class)
		else:
			batch_avg = (class_prob)/ (true_class) + batch_avg
	return batch_avg / batch_size

def compute_iou(x_pred, x_output):
	_, x_pred_label = torch.max(x_pred, dim=1)
	x_output_label = x_output.type(torch.LongTensor).cuda(c)
	
	batch_size = x_pred.size(0)
	for i in range(batch_size):
		if i == 0:
			pixel_acc = torch.div(torch.sum(torch.eq(x_pred_label[i], x_output_label[i]).type(torch.FloatTensor)),
				torch.sum((x_output_label[i] >= 0).type(torch.FloatTensor)))
		else:
			pixel_acc = pixel_acc + torch.div(torch.sum(torch.eq(x_pred_label[i], x_output_label[i]).type(torch.FloatTensor)),
				torch.sum((x_output_label[i] >= 0).type(torch.FloatTensor)))
	return pixel_acc / batch_size


def depth_error(x_pred, x_output):
	binary_mask = (torch.sum(x_output, dim=1) != 0).unsqueeze(1).cuda(c)
	x_pred_true = x_pred.masked_select(binary_mask)
	x_output_true = x_output.masked_select(binary_mask)
	abs_err = torch.abs(x_pred_true - x_output_true)
	rel_err = torch.abs(x_pred_true - x_output_true) / x_output_true
	return torch.sum(abs_err) / torch.nonzero(binary_mask).size(0), torch.sum(rel_err) / torch.nonzero(binary_mask).size(0)



if __name__ == "__main__":
	train_set = NYUv2(root="data_city", train=True)
	val_set = NYUv2(root="data_city", train=False)
	
	# file_loss1 = open('./enc_dense_loss_semantic', 'w')
	file_loss1 = open('./weight_uncertainty_files/classes_7_semantic_loss_weight_uncertainry', 'w')
	file_loss2 = open('./weight_uncertainty_files/classes_7_depth_loss_weight_uncertainry', 'w')
	file_loss = open('./weight_uncertainty_files/classes_7_total_loss_weight_uncertainry', 'w')
	file_weight = open('./weight_uncertainty_files/classes_7_weights_in_weight_uncertainry', 'w')
	file_acc = open('./weight_uncertainty_files/classes_7_accuracy_train_test_weight_uncertainry', 'w')
	# file_coeff_1 = open('./enc_dense_coeff_1', 'w')
	# file_coeff_2 = open('./enc_dense_coeff_2', 'w')
	# scheduler = optim.lr_scheduler.StepLR(opt, step_size=140, gamma=0.5)

	batch_size, c = (8,0)
	train_loader = torch.utils.data.DataLoader(dataset=train_set, batch_size=batch_size, shuffle=True)
	val_loader = torch.utils.data.DataLoader(dataset=val_set, batch_size=batch_size, shuffle=False)

	train_len = len(train_loader)
	val_len = len(val_loader)
	print("number of tuples in training set is: ", train_len)
	print("number of tuples in validation set is: ", val_len)

	model = UNet(3,7,1)
	if torch.cuda.device_count() > 1:
		print("Let's use", torch.cuda.device_count(), "GPUs!")
		# dim = 0 [30, xxx] -> [10, ...], [10, ...], [10, ...] on 3 GPUs
		model = nn.DataParallel(model)
	#model = nn.DataParallel(UNet(3,6,1))
	model.cuda()

	opt = optim.Adam(model.parameters(), lr=1e-4)
	scheduler = optim.lr_scheduler.MultiStepLR(opt, [100, 150], gamma=0.5)
	total_epoch = 200

	sigma_1 = torch.rand(1,1).cuda(c)
	sigma_2 = torch.rand(1,1).cuda(c)

	for epoch in range(total_epoch):
		print("\nepoch number: ", epoch)
		train_list_abs_err = []
		train_list_rel_err = []
		train_list_iou = []
		train_list_miou = []

		test_list_abs_err = []
		test_list_rel_err = []
		test_list_iou = []
		test_list_miou = []		

		list_loss_train = []
		list_loss_test = []
		scheduler.step()
		model.train()

		learning_rate = 0.001
		
		iter_train_loader = iter(train_loader)
		for k in range(train_len):
			image, depth, label= next(iter_train_loader)
			train_image = Variable(image).cuda(c)
			train_depth = Variable(depth).cuda(c)
			train_label = Variable(label.type(torch.LongTensor)).cuda(c)
			output1, output2 = model(train_image)
			opt.zero_grad()

			train_loss1 = nn.functional.cross_entropy(output1, train_label, ignore_index=-1)
			binary_mask = (torch.sum(output2, dim=1) != 0).type(torch.FloatTensor).unsqueeze(1).cuda(c)
			train_loss2 = torch.sum(torch.abs(output2 - train_depth) * binary_mask) / torch.nonzero(binary_mask).size(0)
			train_loss = (1/(2*sigma_1*sigma_1))*train_loss1 + (1/(sigma_2*sigma_2))*train_loss2 + torch.log(sigma_1) + torch.log(sigma_2)
			train_loss.backward()
			opt.step()

			sigma_1 = sigma_1 - (learning_rate/sigma_1)*(1 - (train_loss1.item()/(sigma_1*sigma_1)))
			sigma_2 = sigma_2 - (learning_rate/sigma_2)*(1 - (2*train_loss2.item()/(sigma_2*sigma_2)))

			temp_train_miou = compute_miou(output1, label)
			temp_train_iou = compute_iou(output1, label)
			temp_train_abs_err, temp_train_rel_err = depth_error(output2, train_depth)			
			
			list_loss_train.append(batch_size*train_loss.item())
			train_list_iou.append(batch_size*temp_train_iou.item())
			train_list_miou.append(batch_size*temp_train_miou.item())
			train_list_abs_err.append(batch_size*temp_train_abs_err.item())
			train_list_rel_err.append(batch_size*temp_train_rel_err.item())

		model.eval()
		with torch.no_grad():
			iter_test_loader = iter(val_loader)
			for k in range(val_len):
				test_image, test_depth, test_label= next(iter_test_loader)
				x = Variable(test_image).cuda(c)
				y_1 = Variable(test_depth).cuda(c)
				cuda_test_label = Variable(test_label.type(torch.LongTensor)).cuda(c)
				pred1, pred2 = model(x)

				test_loss1 = nn.functional.cross_entropy(pred1, cuda_test_label,ignore_index=-1)
				binary_mask = (torch.sum(pred2, dim=1) != 0).type(torch.FloatTensor).unsqueeze(1).cuda(c)
				test_loss2 = torch.sum(torch.abs(pred2 - y_1) * binary_mask) / torch.nonzero(binary_mask).size(0)
				test_loss = (1/(2*sigma_1*sigma_1))*test_loss1 + (1/(sigma_2*sigma_2))*test_loss2 + torch.log(sigma_1) + torch.log(sigma_2)

				temp_test_miou = compute_miou(pred1, test_label)
				temp_test_iou = compute_iou(pred1, test_label)
				temp_test_abs_err, temp_test_rel_err = depth_error(pred2, y_1)

				list_loss_test.append(batch_size*test_loss.item())
				test_list_iou.append(batch_size*temp_test_iou.item())
				test_list_miou.append(batch_size*temp_test_miou.item())
				test_list_abs_err.append(batch_size*temp_test_abs_err.item())
				test_list_rel_err.append(batch_size*temp_test_rel_err.item())

		epoch_loss_train = sum(list_loss_train)/(batch_size*train_len)
		train_iou = sum(train_list_iou)/(batch_size*train_len)
		train_miou = sum(train_list_miou)/(batch_size*train_len)
		train_abs_err = sum(train_list_abs_err)/(batch_size*train_len)
		train_rel_err = sum(train_list_rel_err)/(batch_size*train_len)


		epoch_loss_test = sum(list_loss_test)/(batch_size*val_len)
		test_iou = sum(test_list_iou)/(batch_size*train_len)
		test_miou = sum(test_list_miou)/(batch_size*train_len)
		test_abs_err = sum(test_list_abs_err)/(batch_size*train_len)
		test_rel_err = sum(test_list_rel_err)/(batch_size*train_len)


		file_loss.write(str(epoch_loss_train)+","+str(epoch_loss_test)+"\n")
		file_weight.write(str((1/(2*sigma_1*sigma_1)))+","+str((1/(sigma_2*sigma_2)))+"\n")
		file_acc.write(str(train_iou)+","+str(train_miou)+","+str(test_iou)+","+str(test_miou)+","+str(train_abs_err)+","+str(train_rel_err)+","+str(test_abs_err)+","+str(test_rel_err)+"\n")

		print("training loss: ", epoch_loss_train, train_abs_err, "	" ,train_rel_err, " ", train_miou, "	", train_iou, " ", "testing loss:", epoch_loss_test, test_abs_err, test_rel_err, test_miou, " ", test_iou)
		print("\nweights are: ", (1/(2*sigma_1*sigma_1)), (1/(sigma_2*sigma_2)))